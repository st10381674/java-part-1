/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_lab
 */
class Login {
    
//Declaring the attributes
String username;
String password;

//Creating constructors
    public Login() {
    this.username = "";
    this.password = "";
    }
//Generating paramiterized constructors
    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

//Generating the set method 
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
   
    //Generating the get method 
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
  
    //Creating the Boolean: checkUserName Method for username
    public Boolean checkUserName(){
    //Ckecking that the username has an _ and contains not more than 5 characters
    return (getUsername().contains("_")) && (getUsername().length() <=5);  
    }
    
    //Creating  the Boolean: checkPasswordComplexity
    public Boolean checkPasswordComplexity(){
        //Declare boolean to check each complexity conditions
        Boolean hasAtleastEightChar = false;
        Boolean hasCapitalLetter = false;
        Boolean containNumber = false;
        Boolean containSpecChar = false;
        
        //Declaring a string that contains all special characters
        String specialChars = "~`!@#$%^&*()-_=+\\|[{]};:'\",<.>/?";
        
        //Declare a variable that holds the current char/letter of the password
        char currentLetter;
        
        //Traversing the password to check each condition with every single characters/letters
        for (int strIndex = 0; strIndex < getPassword().length(); strIndex++) 
        {
           //Assign each letter based on its position into currentLetter
            currentLetter = getPassword().charAt(strIndex);
            
            //check if the password has at least 8 characters long
            if(getPassword().length() >=8){
               hasAtleastEightChar = true; //If the password has at least 8 chars, then atleastEightChar variable value will be true
            }
            //Check if the current char is a capital letter
            else if(Character.isUpperCase(currentLetter)){ 
                hasCapitalLetter = true; 
            }
            //Check if the password contains a number
            else if (Character.isDigit(currentLetter)){
                containNumber = true;
            }
            //Check if the password has special charecters
            else if (specialChars.contains(String.valueOf(currentLetter))){
                containSpecChar = true;
            }
        }
        

         return hasAtleastEightChar && hasCapitalLetter && containNumber && containSpecChar;
           
        }//End of the Method
    
    
    //Method registerUser
    public String registerUser(){
        //Declaring variables
        String message_to_display = "";
        Boolean check_user_name;
        Boolean check_pass_complex;
        
        //Calling the boolean checkUserName method
        check_user_name = checkUserName();
        //Calling the boolean checkPasswordComplexity method
        check_pass_complex = checkPasswordComplexity();
        
        //The message to display when the username is incorrectly formatted
        //Checking if the username is not well formated (not having an _ and has more than 5 chars)
        if (!check_user_name){
            message_to_display = "Username is not correctly formatted, please ensure that your username contains "
                    + "an underscore and is no more than 5 characters in length." ;
        }
        //Check the that the password does not meet the requirements
        else if (!check_pass_complex){
            message_to_display = "Password is not correctly formatted, please ensure that the password contains at least 8"
                                    + " characters, a capital letter, a number and special character";
        } 
        //Check if both conditions have been met
        else if (check_user_name && check_pass_complex){
            message_to_display = "Welcome " + getUsername() + "it is great to see you again.";
        }
         
     return message_to_display;
    }
    
    //Create a method that checks if the loging details are correct/macthes the details stored
    
    public Boolean loginUser()  
    {
        String stored_UserName = "";
        String stored_parPasswor = "";
        Boolean userDetails_checked = false;
        
        //Check if the details entered matches the details provided while registering
        if ( (getUsername().equalsIgnoreCase(stored_UserName)) &&  
            (getPassword().equalsIgnoreCase(stored_parPasswor)) )
        {
          userDetails_checked = true;  
        }else {
            userDetails_checked = false;
        }
        return userDetails_checked;
    }
    
    
    //Method returnLohinStatus
    public String returnLoginStatus(){
        String login_Status = "";
       
        if(loginUser()){
            login_Status = "Login successful, Welcome";
        
        }
        return login_Status;
      
    }
   
    }  //END OF THE CLASS, LOGIN
    
    
    