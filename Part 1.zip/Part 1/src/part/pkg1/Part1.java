/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package part.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Part1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    

        //Declaring the variables     
        String username ="";
        String password="";
        String firstName ="";
        String lastName="";

        //Decalare boolean variables to store the methods created at Login class
        Boolean check_username;
        Boolean check_password;

        //Declare objects
        Login loginObj = new Login();

        //Assign methods into the boolean variables
        check_username = loginObj.checkUserName();
        check_password = loginObj.checkPasswordComplexity();
        
        Object[] options = {"REGISTER", "LOGIN" , "EXIT"};
    int choice = JOptionPane.showOptionDialog(null, "SELECT YOUR OPTION","REGISTER AND LOGIN ", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE , null, options, null);
    while (choice != JOptionPane.CLOSED_OPTION && choice !=2 ){
        switch (choice){
            case 0 -> register(firstName, lastName, username, password);
            case 1 -> login(username,password);
           
                
        }
        choice = JOptionPane.showOptionDialog(null, "SELECT YOUR OPTION", "REGISTER AND LOGIN", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, null, options, null);
    }
    
    JOptionPane.showMessageDialog(null, "THANK YOU FOR USING OUR SYSTEM");
        
        
      
        //Check username 
        if (!check_username) {
            System.out.println("Username is not correctly formatted, please ensure"
                    + " that your username contains "
                    + "an underscore and is no more than 5 characters in length");

            // username = scanObj.nextLine(); //Get the correct username from the user 
            //JOptionPane.showMessageDialog(null, "Username successfully captured", "Perfect Username");
        } else {
            System.out.println("Username successfully captured");
        }

        System.out.println("please enter your password here");
        // password = scanObj.nextLine();

        // loginObj.setPassword(password);
        //Check password
        if (check_password) {
            System.out.println("Password successfully captured");
        } else {
            System.out.println("“Password is not correctly formatted, please ensure that the password "
                    + "contains at least 8 characters, a capital letter, a number and a special character.");

            // password = scanObj.nextLine(); //Get the correct password
        }

        //initializing the object
        // loginObj = new Login(username, password);
        if (loginObj.loginUser()) {
            //System.out.println("“Welcome " + firstName + ", " + lastName + " it is great to see you again.");
        } else {
            System.out.println("Username or password incorrect, please try again");
        }

    }

//    public static Login loginDetails() {
//        String userLoginName = JOptionPane.showInputDialog(null, "Enter your username");
//        String userLoginPassword = JOptionPane.showInputDialog(null, "Enter your password");
//       
//        return new Login(userLoginName, userLoginName);
//
//    }

    //Method to get inputs from the user for registration
    public static void register(String userfirstName,String lastName, String userRegName, String userRegpassword ) {
        userfirstName = JOptionPane.showInputDialog(null, "Enter your Firstname");
         lastName = JOptionPane.showInputDialog(null, "Enter  your Lastname");
        userRegName = JOptionPane.showInputDialog(null, "Enter your username");
        userRegpassword = JOptionPane.showInputDialog(null, "Enter your password");

        Login user0bj = new Login();
        String result = user0bj.registerUser();
        JOptionPane.showMessageDialog(null, result);

    }

    private static void login(String username, String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
